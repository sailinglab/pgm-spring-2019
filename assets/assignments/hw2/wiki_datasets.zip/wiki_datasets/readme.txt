1.wiki_vocab.txt 

contains 1000 words
the format of each line: [word] \t [wordid]


2.wiki_docs.txt

contains 2866 documents
each line corresponds to one document, containing a list of ordered words
